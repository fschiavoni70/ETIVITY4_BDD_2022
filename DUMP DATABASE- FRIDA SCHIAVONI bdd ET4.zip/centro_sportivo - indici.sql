CREATE INDEX `idx_transiti_Data`  ON `centro_sportivo`.`transiti` (Data) 
COMMENT 'ottimizzare query per controllo giornaliero dei transiti'
ALGORITHM DEFAULT LOCK DEFAULT;

CREATE INDEX `idx_transiti_CodTesserino_Data_Ora`  ON `centro_sportivo`.`transiti` (CodTesserino, Data, Ora)
COMMENT 'ottimizzare query di controllo periodico dei transiti dei dipendenti per segnalare anomalie e ritardi'
ALGORITHM DEFAULT LOCK DEFAULT;

CREATE INDEX `idx_prenotazioni_corsi_Data_CodFiscaleCliente_IdOrario`  ON `centro_sportivo`.`prenotazioni_corsi` (Data, CodFiscaleCliente, IdOrario)
 COMMENT 'Ottimizzare query di verifica dell’esistenza della prenotazione per inserirla oppure per annullare la prenotazione cambiando il valore del campo 
 Stato'
 ALGORITHM DEFAULT LOCK DEFAULT;

CREATE INDEX `idx_prenotazioni_sale_impianti_Data_CodFiscaleCliente_IdOrario`  ON `centro_sportivo`.`prenotazioni_sale_impianti` (Data, CodFiscaleCliente, IdOrario)
 COMMENT 'Ottimizzare query di verifica dell’esistenza della prenotazione per inserirla oppure per annullare la prenotazione cambiando il valore del campo Stato' 
 ALGORITHM DEFAULT LOCK DEFAULT;
 
 
CREATE INDEX `idx_prenotazioni_servizi_Data_CodFiscaleCliente_IdOrario`  ON `centro_sportivo`.`prenotazioni_servizi` (Data, CodFiscaleCliente, IdOrario)
COMMENT 'Ottimizzare query di verifica dell’esistenza della prenotazione per inserirla oppure per annullare la prenotazione cambiando il valore del campo Stato' 
ALGORITHM DEFAULT LOCK DEFAULT;
 
 
CREATE INDEX `idx_manutenzione_impianti_Data_IdSalaImpianto`  ON `centro_sportivo`.`manutenzione_impianti` (Data, IdSalaImpianto)
COMMENT 'Ottimizzare query di controllo giornaliero o periodico delle manutenzioni fatte su un certo impianto o sala'
ALGORITHM DEFAULT LOCK DEFAULT;


CREATE INDEX `idx_manutenzione_impianti_CodIntervento`  ON `centro_sportivo`.`manutenzione_impianti` (CodIntervento) 
COMMENT 'ottimizzare query di controllo giornaliero o periodico di manutenzioni specifiche fatte nella struttura, come ad esempio la pulizia'
ALGORITHM DEFAULT LOCK DEFAULT;



