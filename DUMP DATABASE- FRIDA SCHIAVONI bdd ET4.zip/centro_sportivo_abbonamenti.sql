-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: centro_sportivo
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `abbonamenti`
--

DROP TABLE IF EXISTS `abbonamenti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `abbonamenti` (
  `ProgAbbonamento` int NOT NULL AUTO_INCREMENT,
  `IdAbbonamento` varchar(10) NOT NULL,
  `CodFiscaleCliente` char(16) NOT NULL,
  `CodSconto` varchar(10) DEFAULT NULL,
  `DataInizio` date NOT NULL,
  PRIMARY KEY (`ProgAbbonamento`),
  UNIQUE KEY `ProgAbbonamento` (`ProgAbbonamento`),
  KEY `IdAbb_fk` (`IdAbbonamento`),
  KEY `CodSconto_fk` (`CodSconto`),
  KEY `CFisc_fk` (`CodFiscaleCliente`),
  CONSTRAINT `CFisc_fk` FOREIGN KEY (`CodFiscaleCliente`) REFERENCES `clienti` (`CodiceFiscale`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CodSconto_fk` FOREIGN KEY (`CodSconto`) REFERENCES `sconti` (`CodSconto`) ON UPDATE CASCADE,
  CONSTRAINT `IdAbb_fk` FOREIGN KEY (`IdAbbonamento`) REFERENCES `tipo_abbonamenti` (`IdAbbonamento`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abbonamenti`
--

LOCK TABLES `abbonamenti` WRITE;
/*!40000 ALTER TABLE `abbonamenti` DISABLE KEYS */;
INSERT INTO `abbonamenti` VALUES (1,'SEMCAMPI','DLGNTN65S45V998K','SC1','2022-03-15'),(2,'ANNOFULL','FRGMTT89R54V679L','SC2','2021-11-03'),(3,'ANNOACQUA','SCHFRD70S52C770J','SC1','2022-01-02');
/*!40000 ALTER TABLE `abbonamenti` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-03 17:20:37
