-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: centro_sportivo
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orario_corsi_settimanali`
--

DROP TABLE IF EXISTS `orario_corsi_settimanali`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orario_corsi_settimanali` (
  `IdOrario` varchar(10) NOT NULL,
  `CodCorso` varchar(10) NOT NULL,
  `CodScaglioneOrario` char(10) NOT NULL,
  `GiornoSettimana` varchar(12) NOT NULL,
  PRIMARY KEY (`IdOrario`),
  UNIQUE KEY `IdOrario` (`IdOrario`),
  KEY `CodCorso_fk` (`CodCorso`),
  KEY `CodScaglioneOrario_fk` (`CodScaglioneOrario`),
  CONSTRAINT `CodCorso_fk` FOREIGN KEY (`CodCorso`) REFERENCES `tipologia_corsi` (`IdCorso`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CodScaglioneOrario_fk` FOREIGN KEY (`CodScaglioneOrario`) REFERENCES `scaglioni_orari` (`IdScaglioneOrario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orario_corsi_settimanali`
--

LOCK TABLES `orario_corsi_settimanali` WRITE;
/*!40000 ALTER TABLE `orario_corsi_settimanali` DISABLE KEYS */;
INSERT INTO `orario_corsi_settimanali` VALUES ('ACQF4MLU','ACQUAFIT','SCA04M','Lunedì'),('ACQF4MVE','ACQUAFIT','SCA04M','Venerdì'),('ACQW1SGI','ACQUAWALK','SCA01S','Giovedì'),('ACQW1SMA','ACQUAWALK','SCA01S','Martedì'),('CAL17MMA','CALE1','SCA07M','Mercoledì'),('CAL24PMA','CALE2','SCA04P','Martedì'),('CAL4MME','CALE2','SCA04M','Mercoledì'),('CAL6MME','CALE1','SCA06M','Mercoledì'),('CROS1MLU','CROSS1','SCA01M','Lunedì'),('CROS3MGI','CROSS1','SCA03M','Giovedì'),('CROS4MLU','CROSS2','SCA04M','Lunedì'),('CROS7MME','CROSS2','SCA07M','Mercoledì'),('FLY11SVE','FLY1','SCA01S','Venerdì'),('FLY13MME','FLY1','SCA03M','Mercoledì'),('FLY27MMA','FLY2','SCA07M','Martedì'),('FU4PMA','FUNCT','SCA04P','Martedì'),('HI1SME','HIIT','SCA01S','Mercoledì'),('IDRO7MVE','IDROBIKE','SCA07M','Venerdì'),('NU12PLU','NUOTO2','SCA02P','Lunedì'),('NU12PMA','NUOTO1','SCA02P','Martedì'),('PAD4MGI','PADDLE1','SCA04M','Giovedì'),('PAN3SLU','PANCA','SCA03S','Lunedì'),('PO2PVE','POSTURALE','SCA02P','Venerdì'),('SP1SVE','SPINN1','SCA01S','Venerdì'),('SP3SGI','SPINN2','SCA03S','Giovedì'),('SP4PVE','SPINN2','SCA04P','Venerdì'),('TE4MLU','TENNIS1','SCA04M','Lunedì'),('WA4PGI','WALK1','SCA04P','Giovedì'),('WA4PMA','WALK1','SCA04P','Martedì'),('WA7MGI','WALK2','SCA07M','Giovedì'),('YO2PME','YOBASE','SCA02P','Mercoledì'),('ZU4MLU','ZUMBA','SCA04M','Lunedì'),('ZU5MGI','ZUMBA','SCA05M','Giovedì');
/*!40000 ALTER TABLE `orario_corsi_settimanali` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-03 17:20:39
