-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: centro_sportivo
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orario_sale_impianti`
--

DROP TABLE IF EXISTS `orario_sale_impianti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orario_sale_impianti` (
  `IdOrario` varchar(10) NOT NULL,
  `IdSalaImpianto` varchar(10) NOT NULL,
  `ScaglioneOrario` char(10) NOT NULL,
  `GiornoSettimana` varchar(12) NOT NULL,
  PRIMARY KEY (`IdOrario`),
  KEY `SalaImpianto_fk8` (`IdSalaImpianto`),
  KEY `IdScaglione_fk4` (`ScaglioneOrario`),
  CONSTRAINT `IdScaglione_fk4` FOREIGN KEY (`ScaglioneOrario`) REFERENCES `scaglioni_orari` (`IdScaglioneOrario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `SalaImpianto_fk8` FOREIGN KEY (`IdSalaImpianto`) REFERENCES `sale_impianti` (`IdSalaImpianto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orario_sale_impianti`
--

LOCK TABLES `orario_sale_impianti` WRITE;
/*!40000 ALTER TABLE `orario_sale_impianti` DISABLE KEYS */;
INSERT INTO `orario_sale_impianti` VALUES ('ATT01PLU','ATTREZZI','SCA01P','Lunedì'),('ATT01SVE','ATTREZZI','SCA01S','Venerdì'),('ATT02PLMA','ATTREZZI','SCA02P','Martedì'),('ATT02SMA','ATTREZZI','SCA02S','Martedì'),('ATT03MLU','ATTREZZI','SCA03M','Lunedì'),('ATT03PME','ATTREZZI','SCA03P','Mercoledì'),('ATT03SME','ATTREZZI','SCA03S','Mercoledì'),('ATT04MMA','ATTREZZI','SCA04M','Martedì'),('ATT04PGI','ATTREZZI','SCA04P','Giovedì'),('ATT04SGI','ATTREZZI','SCA04S','Giovedì'),('ATT05MME','ATTREZZI','SCA05M','Mercoledì'),('ATT05PGI','ATTREZZI','SCA05P','Giovedì'),('ATT06MVE','ATTREZZI','SCA06M','Venerdì'),('BEN01PME','BENESSERE','SCA01P','Mercoledì'),('BEN02MGI','BENESSERE','SCA02M','Giovedì'),('BEN02PMA','BENESSERE','SCA02P','Martedì'),('BEN03MMA','BENESSERE','SCA03M','Martedì'),('BEN03MME','BENESSERE','SCA03M','Mercoledì'),('BEN03PME','BENESSERE','SCA03P','Martedì'),('BEN04MGI','BENESSERE','SCA04M','Giovedì'),('BEN04PGI','BENESSERE','SCA04P','Giovedì'),('IDRO01SGI','IDRO','SCA01S','Giovedì'),('IDRO02PMA','IDRO','SCA02P','Martedì'),('IDRO02SGI','IDRO','SCA03S','Lunedì'),('IDRO03PGI','IDRO','SCA03P','Giovedì'),('IDRO04PMA','IDRO','SCA04P','Martedì'),('PAD102MMA','PADDLE1','SCA02M','Martedì'),('PAD103SMA','PADDLE1','SCA03S','Martedì'),('PAD104PGI','PADDLE1','SCA04P','Giovedì'),('PAD104PLU','PADDLE1','SCA04P','Lunedì'),('PAD202MVE','PADDLE2','SCA02M','Venerdì'),('PAD204MGI','PADDLE2','SCA04M','Giovedì'),('PAD204MMA','PADDLE2','SCA04M','Martedì'),('PAD204PMA','PADDLE2','SCA04P','Martedì'),('PAR01SVE','PARETE','SCA01S','Venerdì'),('PAR02MGI','PARETE','SCA02M','Giovedì'),('PAR03SLU','PARETE','SCA03S','Lunedì'),('TEN102MGI','TENNIS1','SCA02M','Giovedì'),('TEN103SME','TENNIS1','SCA03S','Mercoledì'),('TEN104MMA','TENNIS1','SCA04M','Martedì'),('TEN202MMA','TENNIS2','SCA02M','Martedì'),('TEN202SGI','TENNIS2','SCA02S','Giovedì'),('TEN204MLU','TENNIS2','SCA04M','Lunedì');
/*!40000 ALTER TABLE `orario_sale_impianti` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-03 17:20:41
