-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: centro_sportivo
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orario_servizi`
--

DROP TABLE IF EXISTS `orario_servizi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orario_servizi` (
  `IdOrario` varchar(10) NOT NULL,
  `CodPrestazione` varchar(10) NOT NULL,
  `IdScaglioneOrario` char(10) NOT NULL,
  `GiornoSettimana` varchar(12) NOT NULL,
  PRIMARY KEY (`IdOrario`),
  UNIQUE KEY `IdOrario` (`IdOrario`),
  KEY `CoDPrestazione_fk1` (`CodPrestazione`),
  KEY `IdScaglione_fk` (`IdScaglioneOrario`),
  CONSTRAINT `CoDPrestazione_fk1` FOREIGN KEY (`CodPrestazione`) REFERENCES `servizi_estetico_medici` (`CodPrestazione`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `IdScaglione_fk` FOREIGN KEY (`IdScaglioneOrario`) REFERENCES `scaglioni_orari` (`IdScaglioneOrario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orario_servizi`
--

LOCK TABLES `orario_servizi` WRITE;
/*!40000 ALTER TABLE `orario_servizi` DISABLE KEYS */;
INSERT INTO `orario_servizi` VALUES ('MA104MVE','MASSA1','SCA04M','Venerdì'),('MA105MMA','MASSA1','SCA05M','Martedì'),('MA105MME','MASSA1','SCA05M','Mercoledì'),('MAT06MGI','MASSAT','SCA06M','Giovedì'),('MAT06MLU','MASSAT','SCA06M','Lunedì'),('SOT02PLU','SOLET','SCA02P','Lunedì'),('SOT04PLU','SOLET','SCA04P','Lunedì'),('SOT05PME','SOLET','SCA05P','Mercoledì'),('SOV01PME','SOLEV','SCA01P','Mercoledì'),('SOV03PGI','SOLEV','SCA03P','Giovedì'),('SOV04PVE','SOLEV','SCA04P','Venerdì'),('SOV05PGI','SOLEV','SCA05P','Giovedì'),('SOV05PVE','SOLEV','SCA05P','Venerdì'),('VAG05PMA','VAGO','SCA05P','Martedì'),('VES05PLU','VESTE','SCA05P','Lunedì'),('VNA04PME','VNAGO','SCA04P','Mercoledì'),('VNA04PVE','VNAGO','SCA04P','Venerdì'),('VNU05PGI','VNUTRI','SCA05P','Giovedì'),('VNU05PMA','VNUTRI','SCA05P','Martedì'),('VOS05PLU','VOSTEO','SCA05P','Lunedì'),('VOS05PME','VOSTEO','SCA05P','Mercoledì');
/*!40000 ALTER TABLE `orario_servizi` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-03 17:20:36
