-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: centro_sportivo
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `prenotazioni_servizi`
--

DROP TABLE IF EXISTS `prenotazioni_servizi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prenotazioni_servizi` (
  `IdOrario` varchar(10) NOT NULL,
  `Data` date NOT NULL,
  `CodFiscaleCliente` char(16) NOT NULL,
  `Stato` char(1) NOT NULL DEFAULT 'C',
  PRIMARY KEY (`IdOrario`,`Data`,`CodFiscaleCliente`),
  KEY `CodFiscCliente_fk5` (`CodFiscaleCliente`),
  KEY `idx_prenotazioni_servizi_Data_CodFiscaleCliente_IdOrario` (`Data`,`CodFiscaleCliente`,`IdOrario`) COMMENT 'Ottimizzare query di verifica dell’esistenza della prenotazione per inserirla oppure per annullare la prenotazione cambiando il valore del campo Stato',
  CONSTRAINT `CodFiscCliente_fk5` FOREIGN KEY (`CodFiscaleCliente`) REFERENCES `clienti` (`CodiceFiscale`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `IdOrarioServizio_fk3` FOREIGN KEY (`IdOrario`) REFERENCES `orario_servizi` (`IdOrario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prenotazioni_servizi`
--

LOCK TABLES `prenotazioni_servizi` WRITE;
/*!40000 ALTER TABLE `prenotazioni_servizi` DISABLE KEYS */;
INSERT INTO `prenotazioni_servizi` VALUES ('MA104MVE','2022-04-15','DLGNTN65S45V998K','C'),('MA104MVE','2022-04-21','DLGNTN65S45V998K','C'),('MA104MVE','2022-04-28','DLGNTN65S45V998K','C'),('MAT06MLU','2022-04-21','FRGMTT89R54V679L','C'),('SOT02PLU','2022-04-23','FRGMTT89R54V679L','C'),('SOT02PLU','2022-04-27','FRGMTT89R54V679L','C'),('SOT02PLU','2022-04-28','SCHFRD70S52C770J','C'),('SOT04PLU','2022-04-18','DLGNTN65S45V998K','C'),('SOT04PLU','2022-04-24','DLGNTN65S45V998K','C'),('VNU05PGI','2022-04-22','SCHFRD70S52C770J','C'),('VNU05PGI','2022-04-23','DLGNTN65S45V998K','C'),('VNU05PGI','2022-04-23','FRGMTT89R54V679L','C');
/*!40000 ALTER TABLE `prenotazioni_servizi` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-03 17:20:42
