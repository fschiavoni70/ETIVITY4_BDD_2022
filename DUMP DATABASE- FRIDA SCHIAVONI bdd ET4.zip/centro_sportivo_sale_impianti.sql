-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: centro_sportivo
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sale_impianti`
--

DROP TABLE IF EXISTS `sale_impianti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sale_impianti` (
  `IdSalaImpianto` varchar(10) NOT NULL,
  `Descrizione` varchar(30) DEFAULT NULL,
  `Ubicazione` varchar(30) NOT NULL,
  `CapienzaMax` int NOT NULL,
  PRIMARY KEY (`IdSalaImpianto`),
  UNIQUE KEY `IdSalaImpianto` (`IdSalaImpianto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale_impianti`
--

LOCK TABLES `sale_impianti` WRITE;
/*!40000 ALTER TABLE `sale_impianti` DISABLE KEYS */;
INSERT INTO `sale_impianti` VALUES ('ATTREZZI','Sala Attrezzi ','Piano 1- Edificio 1',50),('BENESSERE','Sale SPA','Piano 2- Edificio 1',30),('CALCIO1','Campo Calcetto','Esterno Campus',10),('CROSSGYM1','Sala CrossGym Grande','Piano 1- Edificio 1',20),('CROSSGYM2','Sala CrossGym Piccola','Piano 1- Edificio 1',20),('ESTETICA1','Sala c. estetico ','Piano 2- Edificio 1',2),('ESTETICA2','Sala massaggi','Piano 2- Edificio 1',2),('FITNESS1','Sala corsi 1','Piano 1- Edificio 1',25),('FITNESS2','Sala corsi 2','Piano 1- Edificio 1',20),('FITNESS3','Sala corsi 3','Piano 1- Edificio 1',30),('IDRO','piscina idro','Piano 0 - Edificio 2',20),('PADDLE1','Campo Paddle 1','Esterno Campus',4),('PADDLE2','Campo Paddle 2','Esterno Campus',4),('PADDLE3','Campo Paddle 3','Esterno Campus',4),('PARETE','Parete roccia','Esterno Campus',10),('RECEPTION','Sala accoglienza','Piano 1- Edificio 1',5),('RISTORO','Bar/ristorante','Esterno Campus',30),('SPOGLIF1','spogliatoi F','Piano 1- Edificio 1',30),('SPOGLIFC','spogliatoi F Campus','Esterno Campus',30),('SPOGLIM1','spogliatoi M','Piano 1- Edificio 1',30),('SPOGLIMC','spogliatoi M Campus','Esterno Campus',30),('STUDIO1','Studio medico 1','Piano 2- Edificio 1',5),('STUDIO2','Studio medico 2','Piano 2- Edificio 1',4),('TENNIS1','Campo Tennis 1','Esterno Campus',4),('TENNIS2','Campo Tennis 2','Esterno Campus',4),('UFFICI','Uff. amm.vi e tecn.','Piano 3- Edificio 1',25),('VASCA25','vasca 25mt','Piano 0 - Edificio 2',30),('VASCA50','vasca 50mt','Piano 0 - Edificio 2',40),('VOLLLEY','Campo volley','Esterno Campus',10),('YOGA1','Sala Yoga 2','Piano 1- Edificio 1',15),('YOGA2','Sala Yoga 1','Piano 1- Edificio 1',15);
/*!40000 ALTER TABLE `sale_impianti` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-03 17:20:43
