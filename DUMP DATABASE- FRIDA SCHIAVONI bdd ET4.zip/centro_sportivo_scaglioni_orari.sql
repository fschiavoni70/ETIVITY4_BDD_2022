-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: centro_sportivo
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `scaglioni_orari`
--

DROP TABLE IF EXISTS `scaglioni_orari`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scaglioni_orari` (
  `IdScaglioneOrario` char(10) NOT NULL,
  `FasciaOrariaAppartenenza` char(10) NOT NULL,
  `Descrizione` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`IdScaglioneOrario`),
  UNIQUE KEY `IdScaglioneOrario` (`IdScaglioneOrario`),
  KEY `IdFasciaOraria_fk1` (`FasciaOrariaAppartenenza`),
  CONSTRAINT `IdFasciaOraria_fk1` FOREIGN KEY (`FasciaOrariaAppartenenza`) REFERENCES `fasce_orarie` (`idFasciaOraria`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scaglioni_orari`
--

LOCK TABLES `scaglioni_orari` WRITE;
/*!40000 ALTER TABLE `scaglioni_orari` DISABLE KEYS */;
INSERT INTO `scaglioni_orari` VALUES ('SCA01M','FASCIA1','h 06.30-07.30'),('SCA01P','FASCIA2','h 13.30-14.30'),('SCA01S','FASCIA3','h 18.30-19.30'),('SCA02M','FASCIA1','h 07.30-08.30'),('SCA02P','FASCIA2','h 14.30-15.30'),('SCA02S','FASCIA3','h 19.30-20.30'),('SCA03M','FASCIA1','h 08.30-09.30'),('SCA03P','FASCIA2','h 15.30-16.30'),('SCA03S','FASCIA3','h 20.30-21.30'),('SCA04M','FASCIA1','h 09.30-10.30'),('SCA04P','FASCIA2','h 16.30-17.30'),('SCA04S','FASCIA3','h 21.30-22.30'),('SCA05M','FASCIA1','h 10.30-11.30'),('SCA05P','FASCIA2','h 17.30-18.30'),('SCA06M','FASCIA1','h 11.30-12.30'),('SCA07M','FASCIA1','h 12.30-13.30');
/*!40000 ALTER TABLE `scaglioni_orari` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-03 17:20:36
