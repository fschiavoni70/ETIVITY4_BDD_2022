-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: centro_sportivo
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tipo_abbonamenti`
--

DROP TABLE IF EXISTS `tipo_abbonamenti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_abbonamenti` (
  `IdAbbonamento` varchar(10) NOT NULL,
  `Descrizione` varchar(30) DEFAULT NULL,
  `Tariffa` int NOT NULL,
  `Durata` int NOT NULL,
  PRIMARY KEY (`IdAbbonamento`),
  UNIQUE KEY `IdAbbonamento` (`IdAbbonamento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_abbonamenti`
--

LOCK TABLES `tipo_abbonamenti` WRITE;
/*!40000 ALTER TABLE `tipo_abbonamenti` DISABLE KEYS */;
INSERT INTO `tipo_abbonamenti` VALUES ('ANNOACQUA','1 anno acqua',450,360),('ANNOCAMPI','1 anno campi',560,360),('ANNOCORSI','Annuale Corsi',560,360),('ANNOFULL','Annuale OMNICOMPRENSIVO',560,360),('DAYACQUA','giornaliero acqua',20,1),('DAYCAMPI','giornaliero campo',25,1),('DAYCORSI','giornaliero corsi',12,1),('DAYFULL','giornaliero OMNICOMPRENSIVO',15,1),('MESEACQUA','30 gg acqua',65,30),('MESEFULL','Mensile OMNICOMPRENSIVO',79,30),('SEMACQUA','6 mesi acqua',280,180),('SEMCAMPI','6 mesi prenot campi',320,180),('SEMCORSI','SEMESTRALE Corsi',220,180),('SEMFULL','Semestrale OMNICOMPRENSIVO',420,180),('TRIMACQUA','3 mesi acqua',150,90),('TRIMCAMPI','3 mesi prenot campi',160,90),('TRIMCORSI','3 mesi corsi',160,90),('TRIMFULL','Trimestrale OMNICOMPRENSIVO',210,90);
/*!40000 ALTER TABLE `tipo_abbonamenti` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-03 17:20:43
