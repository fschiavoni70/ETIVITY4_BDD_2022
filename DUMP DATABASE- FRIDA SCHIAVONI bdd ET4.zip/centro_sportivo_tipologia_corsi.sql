-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: centro_sportivo
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tipologia_corsi`
--

DROP TABLE IF EXISTS `tipologia_corsi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipologia_corsi` (
  `IdCorso` varchar(10) NOT NULL,
  `Descrizione` varchar(30) DEFAULT NULL,
  `Titolare` char(16) NOT NULL,
  `IdSalaImpianto` varchar(10) NOT NULL,
  `NumMin` int NOT NULL,
  `NumMax` int NOT NULL,
  PRIMARY KEY (`IdCorso`),
  UNIQUE KEY `IdCorso` (`IdCorso`),
  KEY `CodFiscale_fk3` (`Titolare`),
  KEY `IdSalaImpianto_fk` (`IdSalaImpianto`),
  CONSTRAINT `CodFiscale_fk3` FOREIGN KEY (`Titolare`) REFERENCES `personale` (`CodiCeFiscale`) ON UPDATE CASCADE,
  CONSTRAINT `IdSalaImpianto_fk` FOREIGN KEY (`IdSalaImpianto`) REFERENCES `sale_impianti` (`IdSalaImpianto`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipologia_corsi`
--

LOCK TABLES `tipologia_corsi` WRITE;
/*!40000 ALTER TABLE `tipologia_corsi` DISABLE KEYS */;
INSERT INTO `tipologia_corsi` VALUES ('ACQUAFIT','Fit acqua','PRSNRC85S78B743K','VASCA25',5,20),('ACQUASPIN','Spin acqua','MGRFRN90J44C770H','VASCA50',5,20),('ACQUAWALK','Pedana acqua','MGRFRN90J44C770H','VASCA50',5,20),('CALE1','Calenistica basic','PRTMNL75F67V770L','FITNESS3',5,20),('CALE2','Calenistica Adv.','PRTMNL75F67V770L','FITNESS3',5,20),('CROSS1','CrossGym Basic','VRTMRT77L89V888J','CROSSGYM1',5,25),('CROSS2','CrossGym Advanced','VRTMRT77L89V888J','CROSSGYM2',5,25),('CYCLING','Spinning percorsi','VRTMRT77L89V888J','FITNESS2',5,25),('FLY1','TRX Training Base','PRTMNL75F67V770L','FITNESS3',5,22),('FLY2','TRX Training Adv.','PRTMNL75F67V770L','FITNESS3',5,22),('FUNCT','Funzionale','VRTMRT77L89V888J','FITNESS1',5,30),('HIIT','Interval Training','VRTMRT77L89V888J','FITNESS3',5,30),('IDROBIKE','Spinn acqua','PRSNRC85S78B743K','VASCA25',5,20),('NUOTO1','Corso Nuoto base','ZMPPTR81J54C660J','VASCA25',5,15),('NUOTO2','Corso Nuoto avanz','ZMPPTR81J54C660J','VASCA50',5,15),('PADDLE1','Corso Paddle base','LPZMRC72S52C770J','PADDLE1',1,4),('PADDLE2','Corso Paddle Adv.','LPZMRC72S52C770J','PADDLE1',1,4),('PANCA','Panca Fitness','FRGMTT89R54V679L','YOGA2',5,25),('POSTURALE','Gymn posturale','PRTMNL75F67V770L','YOGA2',5,15),('SPINN1','Spinning Basic','VRTMRT77L89V888J','FITNESS2',5,25),('SPINN2','Spinning Advanced','VRTMRT77L89V888J','FITNESS2',5,25),('TENNIS1','Corso Tennis base','PRTMNL75F67V770L','TENNIS1',1,4),('TENNIS2','Corso Tennis Adv','PRTMNL75F67V770L','TENNIS1',1,4),('TOTALB','TotalBodyWorkout','VRTMRT77L89V888J','FITNESS1',5,30),('WALK1','Walking pedana Basic','LPZMRC72S52C770J','FITNESS1',5,20),('WALK2','Walking pedana ADV.','LPZMRC72S52C770J','FITNESS1',5,20),('YOAVA','Yoga Advanced','FRGMTT89R54V679L','YOGA1',5,20),('YOBASE','Yoga basic','FRGMTT89R54V679L','YOGA1',5,20),('YOFIT','Yoga Fitness','FRGMTT89R54V679L','YOGA2',5,20),('ZUMBA','Zumba Fitness','VRTMRT77L89V888J','FITNESS2',5,30);
/*!40000 ALTER TABLE `tipologia_corsi` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-03 17:20:41
