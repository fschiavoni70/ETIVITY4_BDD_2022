SELECT  DATE_FORMAT( utc_date() , "%e-%c-%Y" ) as data_verifica_scadenze,
                     DATE_FORMAT( abbonamenti.DataInizio , "%e-%c-%Y" ) as data_inizio,
                     tipo_abbonamenti.Durata as durata_abbonamento,
                     tipo_abbonamenti.Descrizione, 
                     sconti.Descrizione, anagrafica.Nominativo, 
                     anagrafica.Email, anagrafica.Telefono
 FROM abbonamenti, anagrafica, tipo_abbonamenti, sconti
 WHERE abbonamenti.CodFiscaleCliente = anagrafica.CodiceFiscale
 AND  abbonamenti.IdAbbonamento = tipo_abbonamenti.IdAbbonamento
 AND  abbonamenti.CodSconto = sconti.CodSconto
 AND  (tipo_abbonamenti.Durata = 360 OR sconti.Percentuale >=15)