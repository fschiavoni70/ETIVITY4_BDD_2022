SELECT anagrafica.Nominativo, transiti.CodTesserino, 
       DATE_FORMAT(transiti.Data, "%e-%c-%Y" ) as Data_Timbratura,  transiti.Ora, 
       REPLACE( REPLACE(transiti.Verso, 'I' ,'ENTRATA ') ,'U','USCITA ')  As Verso_timbratura,
       orario_lavoro.* , TIMEDIFF(transiti.Ora, orario_lavoro.OraInizio) as scarto,
       MAKETIME(00, 05,00) as Scarto_Tollerato
       FROM personale, orario_lavoro, transiti , anagrafica
WHERE transiti.CodTesserino = personale.CodTesserino
AND transiti.Verso ='I'
AND orario_lavoro.CodOrarioLavoro= personale.CodOrarioLavoro
AND anagrafica.CodiCeFiscale = personale.CodiCeFiscale
AND TIMEDIFF(transiti.Ora, orario_lavoro.OraInizio) > MAKETIME(00 , 05, 00)
UNION
SELECT anagrafica.Nominativo, transiti.CodTesserino, 
       DATE_FORMAT(transiti.Data, "%e-%c-%Y" ) as Data_Timbratura,  transiti.Ora, 
       REPLACE( REPLACE(transiti.Verso, 'I' ,'ENTRATA ') ,'U','USCITA ')  As Verso_timbratura,
       orario_lavoro.* , TIMEDIFF(transiti.Ora, orario_lavoro.OraFine) as  scarto,
       MAKETIME(00, 30,00) as scarto_tollerato
FROM personale, orario_lavoro, transiti , anagrafica
WHERE transiti.CodTesserino = personale.CodTesserino
AND transiti.Verso ='U'
AND orario_lavoro.CodOrarioLavoro= personale.CodOrarioLavoro
AND anagrafica.CodiCeFiscale = personale.CodiCeFiscale
AND TIMEDIFF(transiti.Ora, orario_lavoro.OraFine) > MAKETIME(00, 30, 00)
