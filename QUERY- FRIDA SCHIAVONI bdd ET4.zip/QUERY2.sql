SELECT anagrafica.Nominativo, transiti.CodTesserino, 
       DATE_FORMAT(transiti.Data, "%e-%c-%Y" ) as Data_Timbratura,  transiti.Ora, 
       REPLACE( REPLACE(transiti.Verso, 'I' ,'ENTRATA ') ,'U','USCITA ')  As Verso_timbratura,
       orario_lavoro.*
FROM personale, orario_lavoro, transiti , anagrafica
WHERE transiti.CodTesserino = personale.CodTesserino
AND orario_lavoro.CodOrarioLavoro= personale.CodOrarioLavoro
AND anagrafica.CodiCeFiscale = personale.CodiCeFiscale
AND transiti.Data BETWEEN '2022-05-2' AND '2022-05-05'
ORDER BY personale.CodiCeFiscale, transiti.Data, transiti.Ora, transiti.Verso