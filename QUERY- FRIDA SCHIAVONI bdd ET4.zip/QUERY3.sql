SELECT  REPLACE(transiti.Verso, 'I' ,'ENTRATA ') As Verso_timbratura, anagrafica.Nominativo, orario_lavoro.CodOrarioLavoro, 
        orario_lavoro.OraInizio, DATE_FORMAT(transiti.Data, "%e-%c-%Y" ) as Data_Timbratura, MAX(transiti.Ora) AS CONTROLLO
FROM personale, orario_lavoro, transiti , anagrafica
WHERE transiti.CodTesserino = personale.CodTesserino
AND anagrafica.CodiCeFiscale = personale.CodiCeFiscale
AND orario_lavoro.CodOrarioLavoro= personale.CodOrarioLavoro
AND transiti.Verso ='I'
GROUP BY anagrafica.Nominativo 
UNION
SELECT  REPLACE(transiti.Verso, 'U' ,'USCITA ') As Verso_timbratura, anagrafica.Nominativo, orario_lavoro.CodOrarioLavoro, 
        orario_lavoro.OraFine,  DATE_FORMAT(transiti.Data, "%e-%c-%Y" ) as Data_Timbratura, MIN(transiti.Ora) AS CONTROLLO
FROM personale, orario_lavoro, transiti , anagrafica
WHERE transiti.CodTesserino = personale.CodTesserino
AND anagrafica.CodiCeFiscale = personale.CodiCeFiscale
AND orario_lavoro.CodOrarioLavoro= personale.CodOrarioLavoro
AND transiti.Verso ='U'
GROUP BY anagrafica.Nominativo 
