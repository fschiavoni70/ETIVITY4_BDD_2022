SELECT MAX(massimali.ore_lavorate) AS TotaleOre, massimali.codice as CodLavoro, massimali.lavoro_eseguito as LavoroEseguito FROM 
    (SELECT SUM(manutenzione_impianti.Durata) AS ore_lavorate, 
             manutenzione_impianti.CodIntervento AS codice, 
             tipo_manutenzione.Descrizione as lavoro_eseguito
     FROM  manutenzione_impianti, tipo_manutenzione
     WHERE tipo_manutenzione.CodIntervento =  manutenzione_impianti.CodIntervento
     AND manutenzione_impianti.Data > "2020:04:18"
     GROUP BY manutenzione_impianti.CodIntervento
     ORDER BY manutenzione_impianti.CodIntervento ) AS massimali


