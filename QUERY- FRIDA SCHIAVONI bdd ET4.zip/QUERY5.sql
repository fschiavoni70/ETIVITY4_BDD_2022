SELECT anagrafica.Nominativo, sale_impianti.Descrizione AS Impianto , 
tipo_manutenzione.Descrizione, manutenzione_impianti.OraInizio,
DATE_FORMAT(MAX(manutenzione_impianti.Data),"%e-%c-%Y" ) AS Ultima_data_manutenzione
FROM  manutenzione_impianti, sale_impianti, tipo_manutenzione, anagrafica
WHERE  manutenzione_impianti.CodIntervento = 'VASCA'
AND manutenzione_impianti.CodIntervento=tipo_manutenzione.CodIntervento
AND manutenzione_impianti.CFManutentore = anagrafica.CodiceFiscale 
AND manutenzione_impianti.IdSalaImpianto = sale_impianti.IdSalaImpianto
GROUP BY sale_impianti.IdSalaImpianto

