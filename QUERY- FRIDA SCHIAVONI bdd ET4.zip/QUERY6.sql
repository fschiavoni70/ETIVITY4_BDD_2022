SELECT   prenotazioni_corsi.Data AS DATA_PRENOTAZIONE, scaglioni_orari.Descrizione AS ORARIO_PRENOTAZIONE,
         tipologia_corsi.Descrizione AS CORSO_PRENOTATO, prenotazioni_corsi.CodFiscaleCliente,
         anagrafica.Nominativo AS CLIENTE,  orario_corsi_settimanali.CodCorso      
FROM prenotazioni_corsi, anagrafica, orario_corsi_settimanali,  tipologia_corsi, scaglioni_orari
WHERE prenotazioni_corsi.CodFiscaleCliente = anagrafica.CodiCeFiscale
AND prenotazioni_corsi.IdOrario = orario_corsi_settimanali.IdOrario
AND orario_corsi_settimanali.CodCorso = tipologia_corsi.IdCorso
AND orario_corsi_settimanali.CodScaglioneOrario = scaglioni_orari.IdScaglioneOrario
AND prenotazioni_corsi.Data BETWEEN "2022-04-15" AND "2022-04-24"
AND prenotazioni_corsi.Stato ='C'
ORDER BY  prenotazioni_corsi.Data DESC , scaglioni_orari.Descrizione DESC , anagrafica.Nominativo
