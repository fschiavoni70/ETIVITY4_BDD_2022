SELECT prenotazioni_corsi.IdOrario, count(prenotazioni_corsi.CodFiscaleCliente) AS NUMERO_PRENOTAZIONI, 
       orario_corsi_settimanali.GiornoSettimana, orario_corsi_settimanali.CodScaglioneOrario AS SCAGLIONE,
       tipologia_corsi.Descrizione
FROM prenotazioni_corsi,  orario_corsi_settimanali, tipologia_corsi
WHERE prenotazioni_corsi.IdOrario = orario_corsi_settimanali.IdOrario
AND orario_corsi_settimanali.CodCorso = tipologia_corsi.IdCorso
AND prenotazioni_corsi.Stato ='C'
GROUP BY (prenotazioni_corsi.IdOrario)
HAVING orario_corsi_settimanali.CodScaglioneOrario IN
( SELECT scaglioni_orari.IdScaglioneOrario FROM scaglioni_orari WHERE scaglioni_orari.FasciaOrariaAppartenenza = "FASCIA1")

