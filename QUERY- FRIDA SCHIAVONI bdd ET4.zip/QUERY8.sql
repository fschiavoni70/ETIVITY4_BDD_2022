SELECT DISTINCT anagrafica.Nominativo
FROM prenotazioni_corsi, anagrafica, orario_corsi_settimanali
WHERE prenotazioni_corsi.CodFiscaleCliente = anagrafica.CodiCeFiscale
AND prenotazioni_corsi.IdOrario = orario_corsi_settimanali.IdOrario
AND orario_corsi_settimanali.GiornoSettimana = "Lunedì" 
AND anagrafica.Nominativo <> ANY 
(SELECT DISTINCT anagrafica.Nominativo
FROM prenotazioni_sale_impianti, anagrafica, orario_sale_impianti
WHERE prenotazioni_sale_impianti.CodFiscaleCliente= anagrafica.CodiCeFiscale
AND prenotazioni_sale_impianti.IdOrario = orario_sale_impianti.IdOrario
AND orario_sale_impianti.GiornoSettimana = "Lunedì")
