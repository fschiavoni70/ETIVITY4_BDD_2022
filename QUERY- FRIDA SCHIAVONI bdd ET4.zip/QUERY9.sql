SELECT  DATE_FORMAT( utc_date() , "%e-%c-%Y" ) as data_verifica_scadenze, 
        DATE_FORMAT( abbonamenti.DataInizio , "%e-%c-%Y" ) as data_inizio,
	    tipo_abbonamenti.Durata as durata_abbonamento,
        DATE_FORMAT( (abbonamenti.DataInizio + INTERVAL tipo_abbonamenti.Durata DAY) , "%e-%c-%Y" ) as datascadenza,
        DATEDIFF( abbonamenti.DataInizio + INTERVAL tipo_abbonamenti.Durata DAY, CURDATE()) as giorni_residui, 
        tipo_abbonamenti.Descrizione,
        anagrafica.Nominativo,
        anagrafica.Email, 
        anagrafica.Telefono       
FROM abbonamenti, anagrafica, tipo_abbonamenti 
WHERE abbonamenti.CodFiscaleCliente = anagrafica.CodiceFiscale
AND tipo_abbonamenti.IdAbbonamento=abbonamenti.IdAbbonamento
AND  DATEDIFF( abbonamenti.DataInizio + INTERVAL tipo_abbonamenti.Durata DAY, CURDATE()) < 15
